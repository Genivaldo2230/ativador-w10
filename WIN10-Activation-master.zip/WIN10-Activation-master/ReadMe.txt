Note:-############# This code has been pulled from others github repo #####################################

I have personally tested it and it just works.You can also use it to activate your VMs (if you play with it)

I tried on 04 Jan 2020 check the PROOF.jpeg








@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

W10 Digital License Activation Script
All the files are 100% clean on virus total.

===========================================================
W10 Digital License Activation Script.cmd 
Activate the Windows 10 permanently with digital License.

============================================================
This script does not install any files in your system.
------------------------------------------------------------
Windows update must be enabled at the time of activation.
------------------------------------------------------------
Internet connection is required for instant activation, but
If you're running it offline then the system will autoactivate 
At the next online contact.
------------------------------------------------------------
Use of VPN and privacy, anti spy tools, privacy-based 
hosts and firewall's rules(due to blocking of some ms servers)
may cause problems in successful Activation.
------------------------------------------------------------
After activation,If user reinstall the windows then Retail 
version of Windows will auto activate at first online contact
but
If you are using VL version of Windows 10 then
User will have to insert that windows edition product key to 
activate the system. You can insert the product key manually 
or you can use tool's option 
"Insert default product key"
This saves the generating ticket and activation process.

===========================================================
For Making Preactivated Windows 10 ISO

Use PowerISO software to open your windows 10 ISO.
Now copy the $OEM$ folder from here and paste it in sources
Folder of the ISO. The directory will appear like this
iso:\sources\$OEM$\ Now click the option save as, in PowerISO.
Done.

==========================================================
Supported Windows 10 Editions

Core (Home)
Core (Home) (N)
CoreSingleLanguage 
CoreSingleLanguage (N)
Professional
Professional (N)
ProfessionalEducation
ProfessionalEducation (N)
ProfessionalWorkstation
ProfessionalWorkstation (N)
Education
Education (N)
Enterprise
Enterprise (N)
EnterpriseS (LTSB) 
EnterpriseS (LTSB) (N)


Credits:

s1ave77       - Original Author of Digital License Generation without KMS or predecessor install/upgrade
mephistooo2   - Repacking s1ave77's cmd version
WindowsAddict - Making clean and improved version of mephistooo2's Repack

